

#include<stdio.h>
main(){

printf("Name : Het Patel\n");
printf("Birth date: 15 - 05 - 2005\n");
printf("Age :19\n");
printf("Address : isanpur ahmedabad gujarat india\n");	
}
