#include<stdio.h>
main(){
	int student,total_apple;
	printf("enter the number of student ");
	scanf("%d",&student);
	total_apple = 5 * student;
	
	printf("total students is %d ",total_apple);
	
}
