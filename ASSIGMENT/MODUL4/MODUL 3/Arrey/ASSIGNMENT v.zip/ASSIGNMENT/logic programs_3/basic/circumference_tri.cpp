#include<stdio.h>
main(){
	
	int a,b,c;

	printf("enter a");
	scanf("%d",&a);
	
	printf("enter b");
	scanf("%d",&b);
	
	printf("enter c");
	scanf("%d",&c);
	
	printf("circumference of triangle is %d ",a+b+c);
	
	
	
}
