#include<stdio.h>
main(){
	
 int l;
 int area;
 
 printf("area of sqaure is ");
 printf("enter l");
 scanf("%d",&l);
 
 area = l * l;
 printf(" area is %d",area);
	
}
