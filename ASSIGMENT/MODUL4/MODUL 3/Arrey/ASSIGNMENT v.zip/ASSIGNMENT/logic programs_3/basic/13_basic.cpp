#include<stdio.h>
main(){
	int a = 65;
char c = a;
printf("%c", c);
}
