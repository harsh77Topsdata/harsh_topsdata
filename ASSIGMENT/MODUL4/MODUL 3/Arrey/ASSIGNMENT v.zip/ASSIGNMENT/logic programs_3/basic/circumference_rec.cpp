#include<stdio.h>
main(){
	int a;
	printf("enter a \n ");
	scanf("%d",&a);
	printf("circumference of rectangle is %d ",4*a);
	
	
}
