#include<stdio.h>
main(){
	int days,month;
	printf("enter thee days \n");
	scanf("%d",&days);
	
	month=days/30;
	printf("months is %f",(float)month);
	
	
}
