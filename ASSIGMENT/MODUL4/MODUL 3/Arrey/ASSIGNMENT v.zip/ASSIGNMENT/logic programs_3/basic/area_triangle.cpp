#include<stdio.h>
main(){
	
float b,h;
printf("area of triangle\n");
printf("enter the breath");
scanf("%d\n",&b);

printf("enter the height\n");
scanf("%d\n",&h);



printf("area is %d",(float)0.5*b*h);



	
}
