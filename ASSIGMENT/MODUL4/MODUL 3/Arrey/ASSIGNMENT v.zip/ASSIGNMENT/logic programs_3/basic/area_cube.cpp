#include<stdio.h>
main(){
	
int area,a;
printf("area of cube is : \n");
printf("enter a ");
scanf("%d",&a);


area = 6*a*a;
printf("area is %d",area);

	
}
