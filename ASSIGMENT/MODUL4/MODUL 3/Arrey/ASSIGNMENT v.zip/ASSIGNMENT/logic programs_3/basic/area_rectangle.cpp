#include<stdio.h>
main(){
	int l,area,w;
	printf("area of rectangle is \n");
	printf("enter length and width\n");
	scanf("%d %d \n",&l,&w);
	

    printf("area is ",(float)1*w);
    


}
