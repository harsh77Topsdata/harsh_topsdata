#include<stdio.h>
 
main()
{
int number;
printf("enter the number");
scanf("%d",&number);

printf("number to ascii value is %d",number+48);
	
	
}

