#include<stdio.h>
main()
{
	int a,cir_sq;
	printf("enter the a ");
	scanf("%d",&a);
	
	cir_sq=4*a;
	printf("circumference of square is %d",cir_sq);
}

