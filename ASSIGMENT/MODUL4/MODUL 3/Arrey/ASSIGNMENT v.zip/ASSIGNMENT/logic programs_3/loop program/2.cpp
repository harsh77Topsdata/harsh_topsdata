#include<stdio.h>
main(){
	int number;
	for(int i=0;i<5;i++)
	{
		printf("Enter the elements :\n");
		scanf("%d",&number);
	}
	for(int i=0;i<=5;i++)
	{
	printf("number at %d is %d\n",i,number);
}
}
