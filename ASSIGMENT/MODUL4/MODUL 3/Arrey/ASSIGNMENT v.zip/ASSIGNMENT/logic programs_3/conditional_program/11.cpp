#include<stdio.h>
main(){
	int a=5;
	a%2==0?printf("number is even "):printf("number is odd");
}
