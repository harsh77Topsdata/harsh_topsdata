#include<stdio.h>
main(){
	char a;
	printf("enter the character  ");
	scanf("%c",&a);
	if(a=='a'||a=='e'||a=='i'||a=='o'||a=='u')
	{
		printf("it is vowel ");
	}
	else{
		printf("it is not a vowel ");
	}
}
