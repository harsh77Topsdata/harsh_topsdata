#include<stdio.h>
main(){
	int month_number;
	printf("enter the month number ");
	scanf("%d",&month_number);
	
	if(month_number ==1 ){
		printf("month is january");
	}
	else if(month_number ==2)
	{
		printf("month is february");
	}
	else if(month_number ==3)
	{
		printf("month is march ");
	}
	else if(month_number ==4)
	{
		printf("month is april ");
	}
	else if(month_number ==5)
	{
		printf("month is may and days = 31");
	}
	else if(month_number ==6)
	{
		printf("month is june  ");
	}
	else if(month_number ==7)
	{
		printf("month is july ");
	}
	else if(month_number ==8)
	{
		printf("month is august ");
	}
	else if(month_number ==9)
	{
		printf("month is september");
	}
	else if(month_number ==10)
	{
		printf("month is october ");
	}
	else if(month_number ==11)
	{
		printf("month is november");
	}
	else if(month_number ==12)
	{
		printf("month is december ");
	}
	
}
