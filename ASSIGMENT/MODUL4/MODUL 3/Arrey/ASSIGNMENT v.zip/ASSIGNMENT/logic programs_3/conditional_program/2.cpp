#include<stdio.h>
main(){
	
	int m;
	printf("enter m ");
	scanf("%d",&m);
	if(m>0)
	{
		printf("n is 1 ");
	}
	else if (m<0)
	{
		printf("n is -1");
	}
	else {
		printf("n is 0");
	}
}
