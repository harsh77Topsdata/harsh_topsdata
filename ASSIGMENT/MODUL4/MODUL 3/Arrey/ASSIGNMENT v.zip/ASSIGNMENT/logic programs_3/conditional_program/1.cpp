#include<stdio.h>
main()
{
	int a,b;
	printf("enter a \n");
	scanf("%d",&a);
	printf("enter b \n");
	scanf("%d",&b);
	
	if(a==b)
	{
		printf("both are equal ");
	}
	else{
		printf("different ");
	}
	
	
	
}
